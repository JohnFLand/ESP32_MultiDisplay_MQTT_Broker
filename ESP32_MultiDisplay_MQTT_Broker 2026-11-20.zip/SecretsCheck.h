// SecretsCheck.h
//
// Include this immediately after #include "secrets.h".
// It stops the build with a clear message when secrets.h is missing its settings,
// e.g. a zero-byte leftover from a broken link, or a different secrets.h picked up
// from an installed library. Without it you get a long list of confusing
// "'WIFI_SSID' was not declared in this scope" errors instead.
//
// ALTITUDE is not checked: User_Setup.h provides a fallback.
// MQTT_DISPLAYS_FALLBACK is not checked: MQTTBroker.cpp provides a fallback.
// deviceMappings (a const array) can't be checked by the preprocessor.

#ifndef SECRETS_CHECK_H
#define SECRETS_CHECK_H

#if !defined(WIFI_SSID) && !defined(WIFI_PASSWORD) && !defined(LATITUDE) && !defined(LOCATION)
  #error "secrets.h defines none of the expected settings. It is probably empty (e.g. a zero-byte file left behind by a broken link) or a different secrets.h is being used. Create it from secrets.h.EXAMPLE or restore the link to your shared copy."
#else
  #ifndef WIFI_SSID
    #error "secrets.h is missing WIFI_SSID (see secrets.h.EXAMPLE)"
  #endif
  #ifndef WIFI_PASSWORD
    #error "secrets.h is missing WIFI_PASSWORD (see secrets.h.EXAMPLE)"
  #endif
  #ifndef DEFAULT_OTA_PASSWORD
    #error "secrets.h is missing DEFAULT_OTA_PASSWORD (see secrets.h.EXAMPLE)"
  #endif
  #ifndef LATITUDE
    #error "secrets.h is missing LATITUDE (see secrets.h.EXAMPLE)"
  #endif
  #ifndef LONGITUDE
    #error "secrets.h is missing LONGITUDE (see secrets.h.EXAMPLE)"
  #endif
  #ifndef LOCATION
    #error "secrets.h is missing LOCATION (see secrets.h.EXAMPLE)"
  #endif
  #ifndef TIMEZONE
    #error "secrets.h is missing TIMEZONE (see secrets.h.EXAMPLE)"
  #endif
  #ifndef TZ_STRING
    #error "secrets.h is missing TZ_STRING (see secrets.h.EXAMPLE)"
  #endif
  #ifndef HUBITAT_PRESSURE_URL
    #error "secrets.h is missing HUBITAT_PRESSURE_URL (see secrets.h.EXAMPLE)"
  #endif
  #ifndef MQTT_BROKER_IP
    #error "secrets.h is missing MQTT_BROKER_IP (see secrets.h.EXAMPLE)"
  #endif
#endif

#endif // SECRETS_CHECK_H
