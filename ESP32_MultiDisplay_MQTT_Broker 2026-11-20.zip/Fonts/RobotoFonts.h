#ifndef ROBOTO_FONTS_H
  #define ROBOTO_FONTS_H

  //============================================================
  // Roboto Font Collection - Container Header
  //============================================================
  // Font codes now equal point size (e.g. code 16 = 16pt font)
  // Supported sizes: 6, 8, 10, 12, 14, 16, 18, 20, 22, 24,
  //                  26, 28, 30, 32, 34, 36, 38, 40, 42, 44, 46, 48
  //============================================================

  // Include all Roboto Regular fonts from the Fonts/ subdirectory
  #include "Fonts/Roboto_Regular6pt8b.h"
  #include "Fonts/Roboto_Regular8pt8b.h"
  #include "Fonts/Roboto_Regular10pt8b.h"
  #include "Fonts/Roboto_Regular12pt8b.h"
  #include "Fonts/Roboto_Regular14pt8b.h"
  #include "Fonts/Roboto_Regular16pt8b.h"
  #include "Fonts/Roboto_Regular18pt8b.h"
  #include "Fonts/Roboto_Regular20pt8b.h"
  #include "Fonts/Roboto_Regular22pt8b.h"
  #include "Fonts/Roboto_Regular24pt8b.h"
  #include "Fonts/Roboto_Regular26pt8b.h"
  #include "Fonts/Roboto_Regular28pt8b.h"
  #include "Fonts/Roboto_Regular30pt8b.h"
  #include "Fonts/Roboto_Regular32pt8b.h"
  #include "Fonts/Roboto_Regular34pt8b.h"
  #include "Fonts/Roboto_Regular36pt8b.h"
  #include "Fonts/Roboto_Regular38pt8b.h"
  #include "Fonts/Roboto_Regular40pt8b.h"
  #include "Fonts/Roboto_Regular42pt8b.h"
  #include "Fonts/Roboto_Regular44pt8b.h"
  #include "Fonts/Roboto_Regular46pt8b.h"
  #include "Fonts/Roboto_Regular48pt8b.h"
  #include "Fonts/Roboto_Regular54pt7b.h"
  #include "Fonts/Roboto_Regular60pt7b.h"
  #include "Fonts/Roboto_Regular66pt7b.h"
  #include "Fonts/Roboto_Regular72pt7b.h"

  //============================================================
  // Font Code Map  (code = point size)
  //============================================================
  // Font Code |  Size  | Object Name
  // ----------|--------|---------------------------
  //        6  |   6pt  | Roboto_Regular6pt8b
  //        8  |   8pt  | Roboto_Regular8pt8b
  //       10  |  10pt  | Roboto_Regular10pt8b
  //       12  |  12pt  | Roboto_Regular12pt8b
  //       14  |  14pt  | Roboto_Regular14pt8b
  //       16  |  16pt  | Roboto_Regular16pt8b
  //       18  |  18pt  | Roboto_Regular18pt8b
  //       20  |  20pt  | Roboto_Regular20pt8b
  //       22  |  22pt  | Roboto_Regular22pt8b
  //       24  |  24pt  | Roboto_Regular24pt8b
  //       26  |  26pt  | Roboto_Regular26pt8b
  //       28  |  28pt  | Roboto_Regular28pt8b
  //       30  |  30pt  | Roboto_Regular30pt8b
  //       32  |  32pt  | Roboto_Regular32pt8b
  //       34  |  34pt  | Roboto_Regular34pt8b
  //       36  |  36pt  | Roboto_Regular36pt8b
  //       38  |  38pt  | Roboto_Regular38pt8b
  //       40  |  40pt  | Roboto_Regular40pt8b
  //       42  |  42pt  | Roboto_Regular42pt8b
  //       44  |  44pt  | Roboto_Regular44pt8b
  //       46  |  46pt  | Roboto_Regular46pt8b
  //       48  |  48pt  | Roboto_Regular48pt8b
  //       54  |  54pt  | Roboto_Regular54pt7b
  //       60  |  60pt  | Roboto_Regular60pt7b
  //       66  |  66pt  | Roboto_Regular66pt7b
  //       72  |  72pt  | Roboto_Regular72pt7b
  //============================================================

#endif // ROBOTO_FONTS_H
