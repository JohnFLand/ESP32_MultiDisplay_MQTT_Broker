//=============================================================
// MQTTClientMode.ino — MQTT client for the external broker
//
// Active when mqttClientMode == true (persisted setting, change
// via the /mqttmode admin page). In client mode the Elecrow:
//
//   • publishes its retained topics (weather, pressure, pressure
//     history chunks, time) to the external ESP32-S3 broker via
//     the same mqttPublish() facade broker mode uses — no call
//     sites change
//   • subscribes to hubitat/+/devices/<HUBITAT_PRESSURE_DEVICE_ID>
//     and feeds the shared parser in MQTTBroker.cpp
//   • receives display/clear/control/clockconfig over HTTP from
//     the external broker's forwarder — no MQTT subscription needed
//   • does NOT run the embedded broker and does NOT forward to CYDs
//
// Library: PubSubClient (Nick O'Leary) — Library Manager
//=============================================================
#include <PubSubClient.h>
#include <ESPmDNS.h>

#define MQTT_CLIENT_PORT          1883
#define MQTT_CLIENT_BUFFER_SIZE   4096    //history chunks exceed PubSubClient's 256-byte default
#define MQTT_CLIENT_RECONNECT_MS  5000
#define MQTT_CLIENT_ID            "Elecrow-MultiDisplay"

// mDNS name of the external broker (hostname WITHOUT ".local"). Resolved at
// connect time and re-resolved after MQTT_MDNS_RERESOLVE_FAILS consecutive
// failures, so this device follows the broker if its IP changes — no reflash.
// PRECEDENCE: a host customized via the /mqttmode page (i.e. different from
// the compiled MQTT_BROKER_IP default) is honored verbatim and the mDNS
// lookup is skipped — a deliberate manual setting always wins.
// Set to "" to disable mDNS entirely.
#ifndef MQTT_BROKER_MDNS_HOST
  #define MQTT_BROKER_MDNS_HOST   "mqtt-broker"
#endif
#define MQTT_MDNS_RERESOLVE_FAILS 4

static WiFiClient   mqttNetClient;
static PubSubClient psClient(mqttNetClient);
static char         mqttHostBuf[64];             //PubSubClient stores the pointer, not a copy
static ulong        lastClientConnectAttempt = 0;
static bool         clientWasConnected       = false;
static int          mqttFailStreak           = 0;  //consecutive connect failures

//-------------------------------------------------------------
// Incoming messages — only the Hubitat pressure topic is
// subscribed, but match defensively anyway.
//-------------------------------------------------------------
static void mqttClientCallback(char* topic, byte* payload, unsigned int length) {
  String t(topic);
  String p;
  p.reserve(length);
  for (unsigned int i = 0; i < length; i++) p += (char)payload[i];

  DEBUG_PRINTF("MQTT-C: rx %s (%u bytes)\n", topic, length);

  if (t.endsWith("/devices/" + String(HUBITAT_PRESSURE_DEVICE_ID))) {
    mqttHandleHubitatDeviceJson(p);   //shared parser in MQTTBroker.cpp
  }
}

//-------------------------------------------------------------
// Broker host resolution — mDNS first (unless the host was
// customized via /mqttmode), stored/compiled host as fallback.
//-------------------------------------------------------------
static void resolveBrokerHost() {
  bool resolved       = false;
  bool manualOverride = (mqttBrokerHost != MQTT_BROKER_IP);   //set via /mqttmode

  if (manualOverride) {
    DEBUG_PRINTF("MQTT-C: manual host \"%s\" set via /mqttmode — mDNS lookup skipped\n",
                 mqttBrokerHost.c_str());
  } else if (strlen(MQTT_BROKER_MDNS_HOST) > 0) {
    static bool mdnsStarted = false;
    if (!mdnsStarted) {
      String host = "elecrow-" + deviceID;
      host.toLowerCase();
      mdnsStarted = MDNS.begin(host.c_str());   //also advertises this device
      if (!mdnsStarted)
        DEBUG_PRINTLN("MQTT-C: mDNS start failed — using stored host");
    }
    if (mdnsStarted) {
      IPAddress ip = MDNS.queryHost(MQTT_BROKER_MDNS_HOST, 3000);
      if ((uint32_t)ip != 0) {
        strlcpy(mqttHostBuf, ip.toString().c_str(), sizeof(mqttHostBuf));
        resolved = true;
        DEBUG_PRINTF("MQTT-C: resolved %s.local → %s\n",
                     MQTT_BROKER_MDNS_HOST, mqttHostBuf);
      } else {
        DEBUG_PRINTF("MQTT-C: %s.local not found — using stored host\n",
                     MQTT_BROKER_MDNS_HOST);
      }
    }
  }
  if (!resolved)
    strlcpy(mqttHostBuf, mqttBrokerHost.c_str(), sizeof(mqttHostBuf));
  psClient.setServer(mqttHostBuf, MQTT_CLIENT_PORT);
}

// Active (resolved) host — for the /mqttmode status display
String mqttClientActiveHost() {
  return String(mqttHostBuf[0] ? mqttHostBuf : mqttBrokerHost.c_str());
}

//-------------------------------------------------------------
// mqttClientBegin() — called from startMqttBroker() in client mode
//-------------------------------------------------------------
void mqttClientBegin() {
  resolveBrokerHost();
  psClient.setBufferSize(MQTT_CLIENT_BUFFER_SIZE);
  psClient.setCallback(mqttClientCallback);
  DEBUG_PRINTF("MQTT-C: client configured for %s:%d\n", mqttHostBuf, MQTT_CLIENT_PORT);
}

//-------------------------------------------------------------
// Connection attempt — on success, subscribe to the Hubitat
// pressure topic and re-seed the retained topics the external
// broker hands to fresh CYD subscribers. Pressure itself is NOT
// republished here: mqttPublishPressure() adds a reading to the
// forecast buffer, so calling it on every reconnect would insert
// duplicate readings.
//-------------------------------------------------------------
static bool mqttClientTryConnect() {
  DEBUG_PRINTF("MQTT-C: connecting to %s...\n", mqttHostBuf);
  if (!psClient.connect(MQTT_CLIENT_ID)) {
    mqttFailStreak++;
    DEBUG_PRINTF("MQTT-C: connect failed (state %d, streak %d) — retry in %ds\n",
                 psClient.state(), mqttFailStreak,
                 (int)(MQTT_CLIENT_RECONNECT_MS / 1000));
    return false;
  }
  mqttFailStreak = 0;

  String sub = "hubitat/+/devices/" + String(HUBITAT_PRESSURE_DEVICE_ID);
  psClient.subscribe(sub.c_str());
  DEBUG_PRINTF("MQTT-C: connected — subscribed to %s\n", sub.c_str());

  mqttPublishTime();
  if (mqttHistoryReady) mqttPublishPressureHistory();

  return true;
}

//-------------------------------------------------------------
// mqttClientLoop() — called from mqttBrokerUpdate() in client
// mode. Non-blocking reconnect with a fixed retry interval.
//-------------------------------------------------------------
void mqttClientLoop() {
  if (!psClient.connected()) {
    if (clientWasConnected) {
      DEBUG_PRINTLN("MQTT-C: connection to external broker lost");
      clientWasConnected = false;
    }
    if (millis() - lastClientConnectAttempt >= MQTT_CLIENT_RECONNECT_MS) {
      lastClientConnectAttempt = millis();
      if (mqttFailStreak > 0 && mqttFailStreak % MQTT_MDNS_RERESOLVE_FAILS == 0) {
        DEBUG_PRINTLN("MQTT-C: repeated failures — re-resolving broker host");
        resolveBrokerHost();   //broker may have moved; follow it
      }
      clientWasConnected = mqttClientTryConnect();
    }
    return;
  }
  clientWasConnected = true;
  psClient.loop();
}

//-------------------------------------------------------------
// Accessors used by mqttPublish() routing and the /mqttmode page
//-------------------------------------------------------------
bool mqttClientConnected() {
  return psClient.connected();
}

bool mqttClientPublish(const char* topic, const char* payload, bool retain) {
  if (!psClient.connected()) {
    DEBUG_PRINTF("MQTT-C: publish skipped (not connected): %s\n", topic);
    return false;
  }
  bool ok = psClient.publish(topic, (const uint8_t*)payload, strlen(payload), retain);
  if (!ok) {
    DEBUG_PRINTF("MQTT-C: publish FAILED: %s (%d bytes)\n", topic, (int)strlen(payload));
  }
  return ok;
}
